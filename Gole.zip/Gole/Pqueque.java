package Ds;

public class Pqueque {

}
