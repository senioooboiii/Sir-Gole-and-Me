package Ds;

public class queue {

}
