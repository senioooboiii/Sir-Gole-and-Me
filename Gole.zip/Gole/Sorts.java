package Ds;

public class Sorts {

}
