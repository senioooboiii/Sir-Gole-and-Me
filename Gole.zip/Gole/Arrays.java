package Ds;

public class Arrays {

}
