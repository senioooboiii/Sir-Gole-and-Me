import java.util.Scanner;

public class Main {
    // Static inner class for Candidate
    static class Candidate {
        int cid;  // Ito ang ID
        String name;  // Ito ang pangalan
        int score;  // Score o puntos
        long ts;  // Timestamp, maaaring oras ng paglikha o pag-update

        // Constructor para lumikha ng bagong Candidate object
        Candidate(int cid, String name, int score, long ts) {
            this.cid = cid;
            this.name = name;
            this.score = score;
            this.ts = ts;
        }

        // Override ng toString para mag-print ng readable na details
        @Override
        public String toString() {
            return "Candidate{" +
                    "cid=" + cid +
                    ", name='" + name + '\'' +
                    ", score=" + score +
                    ", ts=" + ts +
                    '}';
        }
    }

    // Static inner class for Employer
    static class Employer {
        int eid;  // ID ng employer
        String name;  // Pangalan ng employer
        int urgency;  // Antas ng urgency, maaaring priority level

        // Constructor para lumikha ng bagong Employer object
        Employer(int eid, String name, int urgency) {
            this.eid = eid;
            this.name = name;
            this.urgency = urgency;
        }

        // Override ng toString para mag-print ng readable na details
        @Override
        public String toString() {
            return "Employer{" +
                    "eid=" + eid +
                    ", name='" + name + '\'' +
                    ", urgency=" + urgency +
                    '}';
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice = 0;

        // Constants for Candidates and Employers (integrated from the Arrays logic)
        final int MAX_CANDIDATES = 10;
        final int MAX_EMPLOYERS = 10;

        // Arrays and counters for Candidates and Employers
        Candidate[] candidates = new Candidate[MAX_CANDIDATES];
        Employer[] employers = new Employer[MAX_EMPLOYERS];
        int candidateCount = 0;
        int employerCount = 0;

        // Optional: Pre-insert some initial data (from the original code) - you can remove this if not needed
        // Insert initial candidates
        if (candidateCount < MAX_CANDIDATES) {
            candidates[candidateCount++] = new Candidate(1, "Senio", 95, 1);
        }
        if (candidateCount < MAX_CANDIDATES) {
            candidates[candidateCount++] = new Candidate(2, "Sean", 88, 2);
        }
        if (candidateCount < MAX_CANDIDATES) {
            candidates[candidateCount++] = new Candidate(3, "Harvs", 92, 3);
        }
        // Insert initial employers
        if (employerCount < MAX_EMPLOYERS) {
            employers[employerCount++] = new Employer(1, "CK", 5);
        }
        if (employerCount < MAX_EMPLOYERS) {
            employers[employerCount++] = new Employer(2, "Matt", 3);
        }

        while (choice != 5) {  // Exit is now 5
            System.out.println("====== EVENT SYSTEM MENU ======");
            System.out.println("1. Insert Candidate");
            System.out.println("2. Display Candidates");
            System.out.println("3. Insert Employer");
            System.out.println("4. Display Employers");
            System.out.println("5. Exit");
            System.out.println("===============================");
            System.out.print("Enter choice: ");

            // Input validation (Simple check)
            if (sc.hasNextInt()) {
                choice = sc.nextInt();
            } else {
                System.out.println("\n*** Invalid input. Please enter a number from 1 to 5. ***\n");
                sc.next(); // Consume the invalid input
                continue; // Restart the loop
            }
            
            sc.nextLine(); // Consume the newline character

            // Switch statement para hawakan ang bawat choice
            switch (choice) {
                case 1:
                    System.out.println("\n--- 1. Insert Candidate ---");
                    // Insert Candidate logic (integrated from the original code)
                    if (candidateCount < MAX_CANDIDATES) {
                        System.out.print("Enter Candidate ID: ");
                        int cid = sc.nextInt();
                        sc.nextLine(); // Consume newline
                        System.out.print("Enter Candidate Name: ");
                        String cName = sc.nextLine();
                        System.out.print("Enter Candidate Score: ");
                        int score = sc.nextInt();
                        System.out.print("Enter Timestamp: ");
                        long ts = sc.nextLong();
                        candidates[candidateCount++] = new Candidate(cid, cName, score, ts);
                        System.out.println("Inserted candidate: " + candidates[candidateCount - 1]);
                    } else {
                        System.out.println("Overflow: Cannot insert candidate. Array is full.");
                    }
                    sc.nextLine(); // Consume newline
                    break;
                case 2:
                    System.out.println("\n--- 2. Display Candidates ---");
                    // Display Candidates logic (integrated from the original code)
                    System.out.println("Candidates:");
                    for (int i = 0; i < candidateCount; i++) {
                        System.out.println(candidates[i]);
                    }
                    break;
                case 3:
                    System.out.println("\n--- 3. Insert Employer ---");
                    // Insert Employer logic (similar to Candidate)
                    if (employerCount < MAX_EMPLOYERS) {
                        System.out.print("Enter Employer ID: ");
                        int eid = sc.nextInt();
                        sc.nextLine(); // Consume newline
                        System.out.print("Enter Employer Name: ");
                        String eName = sc.nextLine();
                        System.out.print("Enter Urgency: ");
                        int urgency = sc.nextInt();
                        employers[employerCount++] = new Employer(eid, eName, urgency);
                        System.out.println("Inserted employer: " + employers[employerCount - 1]);
                    } else {
                        System.out.println("Overflow: Cannot insert employer. Array is full.");
                    }
                    sc.nextLine(); // Consume newline
                    break;
                case 4:
                    System.out.println("\n--- 4. Display Employers ---");
                    // Display Employers logic (similar to Display Candidates)
                    System.out.println("Employers:");
                    for (int i = 0; i < employerCount; i++) {
                        System.out.println(employers[i]);
                    }
                    break;
                case 5:
                    System.out.println("\n*** Thank you for using the Event System. Goodbye! ***");
                    break;
                default:
                    System.out.println("\n*** Invalid choice. Please enter a number between 1 and 5. ***\n");
            }
            
            if (choice != 5) {
                System.out.println("\nPress ENTER to continue...");
                sc.nextLine();
            }
        }
        
        sc.close(); 
    }
}
