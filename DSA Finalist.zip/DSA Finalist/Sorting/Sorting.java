class Person {
    String name;
    int score;
    String employer;

    Person(String n, int s, String e) {
        name = n;
        score = s;
        employer = e;
    }

    public String toString() {
        return name + " " + score + " " + employer;
    }
}

public class Sorting {
    // Helper method to swap two elements in the array
    static void swap(Person[] arr, int i, int j) {
        Person temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    // Manual copy of the array to avoid modifying the original
    static Person[] copyArray(Person[] original) {
        Person[] copy = new Person[original.length];
        for (int i = 0; i < original.length; i++) {
            copy[i] = new Person(original[i].name, original[i].score, original[i].employer);
        }
        return copy;
    }

    // Bubble sort by name (alphabetical order)
    static void bubbleSort(Person[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j].name.compareTo(arr[j + 1].name) > 0) {
                    swap(arr, j, j + 1);
                }
            }
        }
    }

    // Insertion sort by score (ascending order)
    static void insertionSort(Person[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            Person key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j].score > key.score) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }

    // Selection sort by employer (alphabetical order)
    static void selectionSort(Person[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j].employer.compareTo(arr[minIdx].employer) < 0) {
                    minIdx = j;
                }
            }
            swap(arr, i, minIdx);
        }
    }

    public static void main(String[] args) {
        // Sample dataset
        Person[] original = {
            new Person("Senio", 85, "Google"),
            new Person("Sean", 92, "Apple"),
            new Person("Harvey", 78, "Microsoft"),
            new Person("Mat", 95, "Amazon"),
            new Person("CK", 88, "Facebook")
        };

        // Bubble sort by name
        Person[] forBubble = copyArray(original);
        bubbleSort(forBubble);
        System.out.println("Bubble sort by name:");
        for (Person p : forBubble) {
            System.out.println(p);
        }
        System.out.println();

        // Insertion sort by score
        Person[] forInsertion = copyArray(original);
        insertionSort(forInsertion);
        System.out.println("Insertion sort by score:");
        for (Person p : forInsertion) {
            System.out.println(p);
        }
        System.out.println();

        // Selection sort by employer
        Person[] forSelection = copyArray(original);
        selectionSort(forSelection);
        System.out.println("Selection sort by employer:");
        for (Person p : forSelection) {
            System.out.println(p);
        }
        System.out.println();

        // Comparison of outputs
        System.out.println("Comparison:");
        System.out.println("- Bubble sort organizes the list alphabetically by name.");
        System.out.println("- Insertion sort organizes the list in ascending order by score.");
        System.out.println("- Selection sort organizes the list alphabetically by employer.");
         
    }
}
