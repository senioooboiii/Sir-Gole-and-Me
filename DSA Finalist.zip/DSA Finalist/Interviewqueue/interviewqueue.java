class Node {
    String data;  // Ito ang data na string na itatago sa node (halimbawa, pangalan)
    Node next;    // Pointer sa susunod na node sa linked list

    Node(String data) {
        this.data = data;
        this.next = null;  // Sa simula, walang susunod na node
    }
}

class Queue {
    Node front, rear;  // Front ay ang unahan ng queue (dito nagde-dequeue), rear ay ang hulihan (dito nag-e-enqueue)

    Queue() {
        front = rear = null;  // Sa simula, walang laman ang queue
    }

    // Enqueue: Magdagdag ng elemento sa hulihan ng queue (FIFO - First In, First Out)
    void enqueue(String data) {
        Node newNode = new Node(data);  // Gumawa ng bagong node
        if (rear == null) {  // Kung walang laman ang queue, itakda ang front at rear sa bagong node
            front = rear = newNode;
            return;
        }
        rear.next = newNode;  // Ikonekta ang bagong node sa hulihan
        rear = newNode;       // Ilipat ang rear sa bagong node
    }

    // Dequeue: Magtanggal ng elemento mula sa unahan ng queue
    // Kung walang laman ang queue, ipakita ang underflow message
    void dequeue() {
        if (front == null) {  // Kung walang laman, underflow
            System.out.println("Underflow: Queue is empty");
            return;
        }
        String dequeued = front.data;  // Kunin ang data ng front
        front = front.next;            // Ilipat ang front sa susunod na node
        if (front == null) {           // Kung walang natira, itakda ang rear sa null
            rear = null;
        }
        System.out.println("Dequeued: " + dequeued);  // Ipakita ang natanggal na elemento
    }

    // Display: Ipakita ang lahat ng elemento sa queue
    void display() {
        if (front == null) {  // Kung walang laman, sabihin na empty
            System.out.println("Queue is empty");
            return;
        }
        Node temp = front;  // Simulan sa front
        while (temp != null) {  // Lumakad hanggang sa dulo
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();  // Bagong linya pagkatapos
    }
}

public class interviewqueue {
    public static void main(String[] args) {
        Queue queue = new Queue();  // Gumawa ng bagong queue

        // Mag-enqueue ng ilang kandidato para sa interview queue
        queue.enqueue("Senio");
        queue.enqueue("Harvey");
        queue.enqueue("Kurt");

        System.out.println("Queue after enqueues:");
        queue.display();  // Dapat ipakita: Senio Harvey Kurt

        // Mag-dequeue (FIFO: Senio ang una na lalabas)
        queue.dequeue();
        System.out.println("Queue after first dequeue:");
        queue.display();  // Dapat ipakita: Harvey Kurt

        // Mag-dequeue ulit
        queue.dequeue();
        System.out.println("Queue after second dequeue:");
        queue.display();  // Dapat ipakita: Kurt

        // Subukang mag-dequeue mula sa walang laman na queue (dapat ipakita ang underflow)
        queue.dequeue();  // Dapat ipakita: Underflow: Queue is empty
        queue.dequeue();  // Isa pang subok para ipakita ang underflow
    }
}
