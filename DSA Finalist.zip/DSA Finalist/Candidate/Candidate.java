import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

class Node {
    int cid;
    Node left, right;

    Node(int cid) {
        this.cid = cid;
        left = right = null;
    }
}

class BST {
    Node root;

    BST() {
        root = null;
    }

    // Insert a new cid into the BST
    void insert(int cid) {
        root = insertRec(root, cid);
    }

    Node insertRec(Node root, int cid) {
        if (root == null) {
            root = new Node(cid);
            return root;
        }
        if (cid < root.cid) {
            root.left = insertRec(root.left, cid);
        } else if (cid > root.cid) {
            root.right = insertRec(root.right, cid);
        }
        // If cid already exists, do nothing (no duplicates)
        return root;
    }

    // Find if a cid exists in the BST
    boolean find(int cid) {
        return findRec(root, cid);
    }

    boolean findRec(Node root, int cid) {
        if (root == null) return false;
        if (root.cid == cid) return true;
        if (cid < root.cid) return findRec(root.left, cid);
        return findRec(root.right, cid);
    }

    // Delete a cid from the BST, handling leaf, one child, and two children cases
    void delete(int cid) {
        root = deleteRec(root, cid);
    }

    Node deleteRec(Node root, int cid) {
        if (root == null) return root;
        if (cid < root.cid) {
            root.left = deleteRec(root.left, cid);
        } else if (cid > root.cid) {
            root.right = deleteRec(root.right, cid);
        } else {
            // Node to be deleted found
            // Case 1: Leaf node (no children)
            if (root.left == null && root.right == null) {
                return null;
            }
            // Case 2: One child
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }
            // Case 3: Two children - get inorder successor (smallest in right subtree)
            root.cid = minValue(root.right);
            root.right = deleteRec(root.right, root.cid);
        }
        return root;
    }

    int minValue(Node root) {
        int minv = root.cid;
        while (root.left != null) {
            minv = root.left.cid;
            root = root.left;
        }
        return minv;
    }

    // Inorder traversal (left, root, right)
    void inorder() {
        inorderRec(root);
        System.out.println();
    }

    void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.print(root.cid + " ");
            inorderRec(root.right);
        }
    }

    // Preorder traversal (root, left, right)
    void preorder() {
        preorderRec(root);
        System.out.println();
    }

    void preorderRec(Node root) {
        if (root != null) {
            System.out.print(root.cid + " ");
            preorderRec(root.left);
            preorderRec(root.right);
        }
    }

    // Postorder traversal (left, right, root)
    void postorder() {
        postorderRec(root);
        System.out.println();
    }

    void postorderRec(Node root) {
        if (root != null) {
            postorderRec(root.left);
            postorderRec(root.right);
            System.out.print(root.cid + " ");
        }
    }
}

public class Candidate {
    public static void main(String[] args) {
        BST bst = new BST();
        Scanner scanner = new Scanner(System.in);

        // Example usage: Insert some cids
        bst.insert(50);
        bst.insert(30);
        bst.insert(70);
        bst.insert(20);
        bst.insert(40);
        bst.insert(60);
        bst.insert(80);

        System.out.println("Inorder traversal after insertions:");
        bst.inorder();

        // Find example
        System.out.println("Find 40: " + bst.find(40));
        System.out.println("Find 100: " + bst.find(100));

        // Delete examples
        System.out.println("Deleting 20 (leaf):");
        bst.delete(20);
        bst.inorder();

        System.out.println("Deleting 30 (one child):");
        bst.delete(30);
        bst.inorder();

        System.out.println("Deleting 50 (two children):");
        bst.delete(50);
        bst.inorder();

        // Traversals
        System.out.println("Preorder traversal:");
        bst.preorder();

        System.out.println("Postorder traversal:");
        bst.postorder();

        // File I/O example (optional, to demonstrate allowed file I/O)
        try {
            PrintWriter writer = new PrintWriter(new File("output.txt"));
            writer.println("Inorder: ");
            // Note: Can't directly write traversal to file without modifying methods, but showing usage
            writer.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }

        scanner.close();
    }
}
