// Custom Candidate class to represent elements in the priority queue
 class Candidate {
    int score;
    int ts; // timestamp, assuming lower ts means higher priority (earlier submission)
    int urgency;
    String name; // optional, for demonstration

    public Candidate(int score, int ts, int urgency, String name) {
        this.score = score;
        this.ts = ts;
        this.urgency = urgency;
        this.name = name;
    }

    @Override
    public String toString() {
        return name + " (score: " + score + ", ts: " + ts + ", urgency: " + urgency + ")";
    }
}

// Custom Priority Queue implementation using a binary heap (max-heap based on custom comparator)
// Priority: higher score first, then lower ts first, then higher urgency first
class MyPriorityQueue {
    private Candidate[] heap;
    private int size;
    private static final int INITIAL_CAPACITY = 10;

    public MyPriorityQueue() {
        heap = new Candidate[INITIAL_CAPACITY];
        size = 0;
    }

    // Push operation: add element and bubble up
    public void push(Candidate candidate) {
        if (size == heap.length) {
            resize();
        }
        heap[size] = candidate;
        bubbleUp(size);
        size++;
    }

    // Pop operation: remove and return the highest priority element, then bubble down
    public Candidate pop() {
        if (size == 0) {
            throw new IllegalStateException("Priority queue is empty");
        }
        Candidate root = heap[0];
        heap[0] = heap[size - 1];
        size--;
        bubbleDown(0);
        return root;
    }

    // Peek operation: return the highest priority element without removing
    public Candidate peek() {
        if (size == 0) {
            throw new IllegalStateException("Priority queue is empty");
        }
        return heap[0];
    }

    // Helper: compare two candidates based on priority rules
    private int compare(Candidate a, Candidate b) {
        if (a.score != b.score) {
            return Integer.compare(b.score, a.score); // higher score first
        }
        if (a.ts != b.ts) {
            return Integer.compare(a.ts, b.ts); // lower ts first
        }
        return Integer.compare(b.urgency, a.urgency); // higher urgency first
    }

    // Bubble up: maintain heap property after insertion
    private void bubbleUp(int index) {
        while (index > 0) {
            int parentIndex = (index - 1) / 2;
            if (compare(heap[index], heap[parentIndex]) <= 0) {
                break; // heap property satisfied
            }
            swap(index, parentIndex);
            index = parentIndex;
        }
    }

    // Bubble down: maintain heap property after removal
    private void bubbleDown(int index) {
        int leftChild = 2 * index + 1;
        int rightChild = 2 * index + 2;
        int largest = index;

        if (leftChild < size && compare(heap[leftChild], heap[largest]) > 0) {
            largest = leftChild;
        }
        if (rightChild < size && compare(heap[rightChild], heap[largest]) > 0) {
            largest = rightChild;
        }
        if (largest != index) {
            swap(index, largest);
            bubbleDown(largest);
        }
    }

    // Swap two elements in the heap
    private void swap(int i, int j) {
        Candidate temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    // Resize the heap array when full
    private void resize() {
        Candidate[] newHeap = new Candidate[heap.length * 2];
        for (int i = 0; i < heap.length; i++) {
            newHeap[i] = heap[i];
        }
        heap = newHeap;
    }

    // Check if queue is empty
    public boolean isEmpty() {
        return size == 0;
    }
}

// Demonstration class with main method (renamed to Priority to match your file name)
public class priority {
    public static void main(String[] args) {
        MyPriorityQueue pq = new MyPriorityQueue();

        // Add candidates to demonstrate priority and tie-breaking
        // Priority: higher score > lower ts > higher urgency
        pq.push(new Candidate(90, 10, 5, "Alice"));   // High score
        pq.push(new Candidate(90, 5, 3, "Bob"));     // Same score as Alice, but lower ts (higher priority)
        pq.push(new Candidate(90, 5, 7, "Charlie")); // Same score and ts as Bob, but higher urgency (higher priority than Bob)
        pq.push(new Candidate(85, 1, 10, "David"));  // Lower score, but lowest ts and high urgency
        pq.push(new Candidate(95, 20, 1, "Eve"));    // Highest score

        System.out.println("Priority Queue Operations Demonstration:");
        System.out.println("Peek: " + pq.peek()); // Should be Eve (highest score)

        System.out.println("\nPopping elements in priority order:");
        while (!pq.isEmpty()) {
            System.out.println("Pop: " + pq.pop());
        }

        // Tie-break demonstration:
        // After popping Eve (95), next should be Charlie (90,5,7) because same score as Alice/Bob, but ts=5 (same as Bob), higher urgency than Bob's 3
        // Then Bob (90,5,3), then Alice (90,10,5) because higher ts than Bob/Charlie
        // Then David (85,1,10)
        // This shows tie-breaking: score first, then ts, then urgency.
    }
}
