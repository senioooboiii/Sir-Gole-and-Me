class Candidate {
    int cid;
    String name;
    int score;
    long ts;

    Candidate(int cid, String name, int score, long ts) {
        this.cid = cid;
        this.name = name;
        this.score = score;
        this.ts = ts;
    }

    @Override
    public String toString() {
        return "Candidate{" +
                "cid=" + cid +
                ", name='" + name + '\'' +
                ", score=" + score +
                ", ts=" + ts +
                '}';
    }
}

class Employer {
    int eid;
    String name;
    int urgency;

    Employer(int eid, String name, int urgency) {
        this.eid = eid;
        this.name = name;
        this.urgency = urgency;
    }

    @Override
    public String toString() {
        return "Employer{" +
                "eid=" + eid +
                ", name='" + name + '\'' +
                ", urgency=" + urgency +
                '}';
    }
}

public class Arrays {
    private static final int MAX_CANDIDATES = 10;
    private static final int MAX_EMPLOYERS = 10;

    private Candidate[] candidates;
    private Employer[] employers;
    private int candidateCount;
    private int employerCount;

    public Arrays() {
        candidates = new Candidate[MAX_CANDIDATES];
        employers = new Employer[MAX_EMPLOYERS];
        candidateCount = 0;
        employerCount = 0;
    }

    // Insert candidate with overflow guard
    public void insertCandidate(Candidate c) {
        if (candidateCount < MAX_CANDIDATES) {
            candidates[candidateCount++] = c;
            System.out.println("Inserted candidate: " + c);
        } else {
            System.out.println("Overflow: Cannot insert candidate. Array is full.");
        }
    }

    // Insert employer with overflow guard
    public void insertEmployer(Employer e) {
        if (employerCount < MAX_EMPLOYERS) {
            employers[employerCount++] = e;
            System.out.println("Inserted employer: " + e);
        } else {
            System.out.println("Overflow: Cannot insert employer. Array is full.");
        }
    }

    // Display all candidates
    public void displayCandidates() {
        System.out.println("Candidates:");
        for (int i = 0; i < candidateCount; i++) {
            System.out.println(candidates[i]);
        }
    }

    // Display all employers
    public void displayEmployers() {
        System.out.println("Employers:");
        for (int i = 0; i < employerCount; i++) {
            System.out.println(employers[i]);
        }
    }

    public static void main(String[] args) {
        Arrays system = new Arrays();

        // Example insertions with small ts values
        system.insertCandidate(new Candidate(1, "Senio", 95, 1));
        system.insertCandidate(new Candidate(2, "Sean", 88, 2));
        system.insertCandidate(new Candidate(3, "Harvs", 92, 3));

        system.insertEmployer(new Employer(1, "CK", 5));
        system.insertEmployer(new Employer(2, "Matt", 3));

        // Try inserting more to test overflow, with incrementing small ts
        for (int i = 4; i <= 12; i++) {
            system.insertCandidate(new Candidate(i, "Candidate" + i, 80 + i, i));
        }

        system.displayCandidates();
        system.displayEmployers();
    }
}
