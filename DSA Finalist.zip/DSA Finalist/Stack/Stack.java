// Custom Stack implementation using linked list (no java.util.* collections allowed)
class MyStack<T> {
    private static class Node<U> {
        U data;
        Node<U> next;
        
        Node(U data) {
            this.data = data;
        }
    }
    
    private Node<T> top;
    private int size = 0;
    
    public void push(T item) {
        Node<T> newNode = new Node<>(item);
        newNode.next = top;
        top = newNode;
        size++;
    }
    
    public T pop() {
        if (isEmpty()) {
            throw new RuntimeException("Stack is empty");
        }
        T data = top.data;
        top = top.next;
        size--;
        return data;
    }
    
    public T peek() {
        if (isEmpty()) {
            throw new RuntimeException("Stack is empty");
        }
        return top.data;
    }
    
    public boolean isEmpty() {
        return top == null;
    }
    
    public int size() {
        return size;
    }
}

// UndoRedo class for multi-step undo/redo (assuming schedule is a string that gets appended to on each operation)
class UndoRedo {
    private MyStack<String> undoStack = new MyStack<>();
    private MyStack<String> redoStack = new MyStack<>();
    private String current = "";
    
    // Perform an operation (e.g., append to the schedule string)
    public void performOperation(String op) {
        undoStack.push(current);
        current += op;
        // Clear redo stack on new operation
        redoStack = new MyStack<>();
    }
    
    // Undo multiple steps
    public void undo(int steps) {
        for (int i = 0; i < steps; i++) {
            if (undoStack.isEmpty()) break;
            redoStack.push(current);
            current = undoStack.pop();
        }
    }
    
    // Redo multiple steps
    public void redo(int steps) {
        for (int i = 0; i < steps; i++) {
            if (redoStack.isEmpty()) break;
            undoStack.push(current);
            current = redoStack.pop();
        }
    }
    
    public String getCurrent() {
        return current;
    }
}

// Main class to demonstrate: 3 operations, undo 2, redo 1
public class Stack {
    public static void main(String[] args) {
        UndoRedo ur = new UndoRedo();
        
        // Perform 3 operations (appending "a", "b", "c")
        ur.performOperation("a");
        ur.performOperation("b");
        ur.performOperation("c");
        System.out.println("After 3 operations: " + ur.getCurrent());  // abc
        
        // Undo 2 steps
        ur.undo(2);
        System.out.println("After undo 2: " + ur.getCurrent());  // a
        
        // Redo 1 step
        ur.redo(1);
        System.out.println("After redo 1: " + ur.getCurrent());  // ab
    }
}
